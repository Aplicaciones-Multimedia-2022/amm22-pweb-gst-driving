#!/bin/sh

gst-launch-1.0 filesrc location = "audiodub.mp3" ! mpegaudioparse ! mpg123audiodec ! tee name=bifurcacion \
 bifurcacion. ! queue ! audioconvert ! audioecho intensity = 0.8 feedback=0.9 delay=400000000 ! audioconvert ! vorbisenc ! oggmux ! tcpserversink host=127.0.0.1 port=6060 \
 bifurcacion. ! queue ! audioconvert ! goom ! videoconvert ! kaleidoscope ! tunnel ! timeoverlay font-desc="Sans,24" ! videoconvert ! theoraenc ! oggmux ! tcpserversink host=127.0.0.1 port=7070 \
 bifurcacion. ! queue ! audioconvert ! audioecho intensity=0.8 feedback=0.9 delay=400000000 ! vorbisenc ! oggmux ! filesink location = "destino.ogg"
