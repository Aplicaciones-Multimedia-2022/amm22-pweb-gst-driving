
let animales = [];
let animales2 = [];

const pigImg = new Image();
pigImg.src = "./assets/img/pig.png";
const pigAudio = new Audio("./assets/media/pig.mp3");

const eleImg = new Image();
eleImg.src = "./assets/img/elephant.png";
const eleAudio = new Audio("./assets/media/elephant.mp3");

const suriImg = new Image();
suriImg.src = "./assets/img/suri.png";
const suriAudio = new Audio("./assets/media/suri.mp3");

const lionImg = new Image();
lionImg.src = "./assets/img/lion.png";
const lionAudio = new Audio("./assets/media/lion.mp3");

class Animal {
  constructor(width,height,color,zona){


    if(zona==3){
      this.posX = Math.floor(Math.random() * ((550-width) - 250 + 1) ) + 250;
    }
    else if(zona==1){
      this.posX = Math.floor(Math.random() * (250-width - 0 + 1) ) + 0;
    }
    else{
      this.posX = Math.floor(Math.random() * ((800-width) - 550 + 1) ) + 550;
    }


    this.posY = -height;
    this.width = width;
    this.height = height;
    this.velY = groundVel;
    this.color = color;
  }

  newPos(){
    this.posY += this.velY;
  }

  drawIt(){

      if(this.color=="pig"){
        ctx.drawImage(pigImg,this.posX,this.posY,this.width,this.height);

      }
      if(this.color=="ele"){
        ctx.drawImage(eleImg,this.posX,this.posY,this.width,this.height);
      }
      if(this.color=="suri"){
        ctx.drawImage(suriImg,this.posX,this.posY,this.width,this.height);
      }
      if(this.color=="lion"){
        ctx.drawImage(lionImg,this.posX,this.posY,this.width,this.height);
      }

  }
}


function setAnimals(){


  let rightOrLeft = Math.floor(Math.random() *2);





    let dificult=50;

    if(fotograma>=1000) dificult = 45;//haciendo que los animales aparezcan cada menos tiempo
    if(fotograma>=2000) dificult = 40;
    if(fotograma>=3000) dificult = 35;
    if(fotograma>=3500) dificult = 30;

    if(fotograma % dificult==0){


        let prob = Math.floor(Math.random()*4);
        if(prob==0){
          animales.unshift(new Animal(70,70,"pig",3));
        }
        if(prob==1){
          animales.unshift(new Animal(70,70,"ele",3));
        }
        if(prob==2){
          animales.unshift(new Animal(52,100,"suri",3));
        }
        if(prob==3){
          animales.unshift(new Animal(80,80,"lion",3));
        }

      }
      for (let i = 0; i < animales.length; i++) {
        animales[i].newPos();
        animales[i].drawIt();

      }

      if(fotograma % (dificult-5)==0){


          let prob = Math.floor(Math.random()*4);
          if(prob==0){
            animales2.unshift(new Animal(70,70,"pig",prob));
          }
          if(prob==1){
            animales2.unshift(new Animal(70,70,"ele",prob));
          }
          if(prob==2){
            animales2.unshift(new Animal(52,100,"suri",prob));
          }
          if(prob==3){
            animales2.unshift(new Animal(80,80,"lion",prob));
          }

        }


    for (let i = 0; i < animales2.length; i++) {

      animales2[i].newPos();
      animales2[i].drawIt();
    }
    if(animales.length > 50){
      animales.pop();
    }
    if(animales2.length > 50){
      animales2.pop();
    }
}
function checkAnimalColision(){
  if(animales.length>0&&animales2.length>0){
     //variable para quedarme con el animal que he atropellado
    for(let i = 0; i < animales.length;i++){
      if(animales[i].color=="ele"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales[i].posX+8 &&
        /*lado derecho del animal*/   coche.posX < animales[i].posX + animales[i].width-9 &&
        /*lado de abajo  del animal*/   coche.posY < animales[i].posY + animales[i].height-6 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales[i].posY+19
       ){


           //vidas--;
           aceleraAudio.pause();
           eleAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;


        }
      }
      if(animales[i].color=="pig"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales[i].posX+10 &&
        /*lado derecho del animal*/   coche.posX < animales[i].posX + animales[i].width-9 &&
        /*lado de abajo  del animal*/   coche.posY < animales[i].posY + animales[i].height-8 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales[i].posY+16
       ){


          aceleraAudio.pause();
          //vidas--;
          pigAudio.play();
          numeroBidones = 0;
          permite = false;
          return true;

        }
      }

      if(animales[i].color=="lion"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales[i].posX+13 &&
        /*lado derecho del animal*/   coche.posX < animales[i].posX + animales[i].width-20 &&
        /*lado de abajo  del animal*/   coche.posY < animales[i].posY + animales[i].height-23 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales[i].posY+35
       ){

           //vidas--;
           aceleraAudio.pause();
           lionAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;

        }
      }

      if(animales[i].color=="suri"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales[i].posX+12 &&
        /*lado derecho del animal*/   coche.posX < animales[i].posX + animales[i].width-19 &&
        /*lado de abajo  del animal*/   coche.posY < animales[i].posY + animales[i].height-5 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales[i].posY+5
       ){

           aceleraAudio.pause();
           //vidas--;
           suriAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;

        }
      }
    }



    for(let i = 0; i < animales2.length;i++){
      if(animales2[i].color=="ele"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales2[i].posX+8 &&
        /*lado derecho del animal*/   coche.posX < animales2[i].posX + animales2[i].width-9 &&
        /*lado de abajo  del animal*/   coche.posY < animales2[i].posY + animales2[i].height-6 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales2[i].posY+19
       ){

           aceleraAudio.pause();
           //vidas--;
           eleAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;

        }
      }

      if(animales2[i].color=="pig"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales2[i].posX+10 &&
        /*lado derecho del animal*/   coche.posX < animales2[i].posX + animales2[i].width-9 &&
        /*lado de abajo  del animal*/   coche.posY < animales2[i].posY + animales2[i].height-8 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales2[i].posY+16
       ){


           aceleraAudio.pause();
           //vidas--;
           pigAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;





        }
      }

      if(animales2[i].color=="lion"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales2[i].posX+13 &&
        /*lado derecho del animal*/   coche.posX < animales2[i].posX + animales2[i].width-20 &&
        /*lado de abajo  del animal*/   coche.posY < animales2[i].posY + animales2[i].height-23 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales2[i].posY+35
       ){


           aceleraAudio.pause();
           //vidas--;
           lionAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;





        }
      }

      if(animales2[i].color=="suri"&&permite==true){
        if(
        /*lado izquioerda del animal*/  coche.posX + coche.width > animales2[i].posX+12 &&
        /*lado derecho del animal*/   coche.posX < animales2[i].posX + animales2[i].width-19 &&
        /*lado de abajo  del animal*/   coche.posY < animales2[i].posY + animales2[i].height-5 &&
        /*lado de arriba del animal*/   coche.posY + coche.height > animales2[i].posY+5
       ){



           aceleraAudio.pause();
           //vidas--;
           suriAudio.play();
           numeroBidones = 0;
           permite = false;
           return true;


        }
      }
    }

  }
}
