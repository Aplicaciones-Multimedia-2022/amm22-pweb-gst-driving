let bidones = [];
const coinAudio = new Audio("./assets/media/gasofa.mp3");
const bidonImg = new Image();
bidonImg.src = "./assets/img/bidon.png"

const outOfGasolineAudio = new Audio("./assets/media/singasofa.mp3");
const aBuenasHorasAudio = new Audio("./assets/media/aBuenasHoras.ogg");
class Bidon {

  constructor(){
    this.posX =  Math.floor(Math.random()*741);
    this.posY = -60;
    this.width = 60;
    this.height = 60;
    this.velY = groundVel-4;
  }
  newPos(){
    this.posY += this.velY;
  }

  drawIt(){
      ctx.fillStyle = "blue";
      ctx.drawImage(bidonImg,this.posX,this.posY,this.width,this.height);
  }
}

function setBidones(){
  if(fotograma % 250==0){
     bidones.unshift(new Bidon());

    }
  for (let i = 0; i < bidones.length; i++) {
    bidones[i].newPos();
    bidones[i].drawIt();
  }
  if(bidones.length > 10){
    bidones.pop();
  }
}

function checkBidonColision(){
  if(bidones.length>0){
    for(let i = 0; i < bidones.length;i++){
      if(
        coche.posX + coche.width > bidones[i].posX &&
        coche.posX < bidones[i].posX + bidones[i].width &&
        coche.posY < bidones[i].posY + bidones[i].height &&
        coche.posY + coche.height > bidones[i].posY
      ){
        if(gasolina<=150){

          aBuenasHorasAudio.load();
          aBuenasHorasAudio.play();
        }
        gasolina +=250;
        numeroBidones++;
        if(numeroBidones==2){
          vidas++;
          numeroBidones=0;
        }


        bidones.splice(i, 1);
        coinAudio.play();

      }
    }
  }
}

 function checkGasolineLevel(){
   if((gasolina<=200)&& fotograma % 150 == 0){
     //aceleraAudio.pause();
     outOfGasolineAudio.play();
     return false;
   }
   if(gasolina<=0){
     aceleraAudio.pause();
     return true;
   }


 }
