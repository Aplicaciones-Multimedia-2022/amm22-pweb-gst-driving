let pajas = [];
let pajas2 = [];
const pajaImg = new Image();
pajaImg.src = "./assets/img/paja.png"
class Paja {

 constructor(lado){


   if(lado=="derecha"){
     this.posX = 750//Math.floor(Math.random() * (750 - 600 + 1) ) + 600;
   }
   if(lado=="izquierda"){
     this.posX = 50//Math.floor(Math.random() * (750 - 0 + 1) ) + 0;
   }

   this.posY = -30;
   this.width = 50;
   this.height = 50;
   if(lado=="derecha"){
     this.velX =  -(Math.floor(Math.random() * (6 - 3 + 1) ) + 3);
   }
   if(lado=="izquierda"){
     this.velX =  (Math.floor(Math.random() * (6 - 3 + 1) ) + 3);
   }

   this.velY = Math.floor(Math.random() * (9 - 5 + 1) ) + 5;

 }
 newPos(){
    this.posX += this.velX;
    this.posY += this.velY;
 }

 drawIt(){
  ctx.drawImage(pajaImg,this.posX,this.posY,this.width,this.height);
 }

}

function setPajas(){


  if((fotograma>1000 && (fotograma%20==0)&&fotograma<1500) || (fotograma>2500&&fotograma%50==0)||(fotograma>3200&&fotograma%40==0)){

      pajas.unshift(new Paja("derecha"));
}
  for (let i = 0; i < pajas.length; i++) {
    pajas[i].newPos();
    pajas[i].drawIt();
  }

  if(pajas.length>0){
    for(let i = 0;i < pajas.length;i++){
      if(pajas[i].posX<(-pajas[i].width)){
        pajas.pop();
       }
     }
   }


 if((fotograma>1500 && (fotograma%20==0)&&fotograma<2000) || (fotograma>2500 && fotograma%50==0)||(fotograma>3200&&fotograma%40==0)){

     pajas2.unshift(new Paja("izquierda"));
}
 for (let i = 0; i < pajas2.length; i++) {
   pajas2[i].newPos();
   pajas2[i].drawIt();
 }

 if(pajas2.length>0){
   for(let i = 0;i < pajas2.length;i++){
     if(pajas2[i].posX<(-pajas2[i].width)){
       pajas2.pop();
      }
    }
  }


}


function chechPajaColision(){
  if(pajas.length>0){
    for(let i=0;i<pajas.length;i++){
      if(coche.posX + coche.width > pajas[i].posX &&
         coche.posX < pajas[i].posX + pajas[i].width &&
         coche.posY < pajas[i].posY + pajas[i].height &&
         coche.posY + coche.height > pajas[i].posY
       ){
         if(pajas[i].velX==-3)coche.velX -=4;
         if(pajas[i].velX==-4)coche.velX -=5;
         if(pajas[i].velX==-5)coche.velX -=6;
         if(pajas[i].velX==-6)coche.velX -=7;

       }
    }
  }

  if(pajas2.length>0){
    for(let i=0;i<pajas2.length;i++){
      if(coche.posX + coche.width > pajas2[i].posX &&
         coche.posX < pajas2[i].posX + pajas2[i].width &&
         coche.posY < pajas2[i].posY + pajas2[i].height &&
         coche.posY + coche.height > pajas2[i].posY
       ){
         if(pajas2[i].velX==3)coche.velX +=4;
         if(pajas2[i].velX==4)coche.velX +=5;
         if(pajas2[i].velX==5)coche.velX +=6;
         if(pajas2[i].velX==6)coche.velX +=7;

       }
    }
  }

}
