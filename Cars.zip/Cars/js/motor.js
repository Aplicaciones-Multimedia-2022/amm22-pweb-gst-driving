  let canvas = document.getElementById("micanvas");
  let ctx = canvas.getContext("2d");
  let c_width = canvas.width;
  let c_height = canvas.height;
  let fotograma = 0;// fotograma del juego( sirve para el tema de cada cuanto aparezcan cosas en el juego)
  let gira;//esta variable se usa para el evento de pulsar las flechas izquierda y derecha
  let tecla;//esta creo que no sirve para nada me olvidé
  let rayas;//el  array de rayas de carretera
  var buleana = true; //es para generar las lineas blancas
  const groundVel = 10;//velocidad del suelo
  var score = 0;//puntuación de "distancia"
  var score_int = 0;//puntuacion de"distancia" en entero
  var gasolina = 500;//la gasolina del coche
  var vidas = 3;//las vidas
  var permite = true;//esta variable sirve para ofrecer invulnerabilidad durante muy poco tiempo al coche, para que se pueda hacer lo de las vidas)
  var permiteCont = 100;//esta variable sirve como contador para ese tiempo de invulnerabilidad
  const circlePosX=30;//positcion x del corazon
  const circlePosY=20;//posicion y del corazon
  var separacion=0;//separacion entre corazones
  var numeroBidones = 0;

  function resetValues(){
             elem.style.display = "flex";
             coche = new Coche();
             animales = [];
             animales2 = [];
             bidones = [];
             humos = [];
             pajas = [];
             pajas2 =[];
             rayas = [];
             fotograma = 0;
             gira = "S";
             buleana = true;
             score = 0;
             score_int = 0;
             gasolina = 500;
             vidas = 3;
             permite = true;
             permiteCont = 100;
             separacion=0;
             numeroBidones = 0;


             for(i=0;i<5;i ++){
               rayas.push(new Raya(30+(i*120)));
             }
             updateGame();
          }

  const br = new Image();//variable de la imagen de fondo
  br.src = "./assets/img/tierra.jpeg";

  const startGame= document.querySelector("#startGame");
  const puntFinal= document.querySelector("#puntFinal");
  const model = document.querySelector("#modelo");
  var elem = document.getElementById("micanvas");

  const backGround = {//
    x: 0,
    y: 0,
    width: c_width,
    height: c_height,
};
  //variabels globales//
  function meteRayas(){

     var last = rayas.length - 1;
     var lastY = rayas[last].y;
     var distRelativa = rayas[0].y;
     if(lastY>=c_height-60 &&(buleana)){
       buleana = false;
       rayas.unshift(new Raya(distRelativa-120));

     }
     if((lastY>=c_height)&& !(buleana)){
       buleana = true;
       rayas.pop();

     }
 }
  function pintaRayas(){

    for(i=0;i<5;i ++){
      rayas[i].draw();
    }
  }
  function mueveRayas(){
    for(i=0;i<rayas.length;i++){
      rayas[i].newPos();
      //rayas[i].draw();
    }
  }
  function Raya(y){
    this.x = 400;
    this.y = y;
    this.width = 10;
    this.height = 60;
    this.vy = groundVel;
    this.newPos = function(){
      this.y += this.vy;
    }
    this.draw = function(){
      ctx.fillStyle = "white";
      ctx.fillRect(this.x,this.y,this.width,this.height);
    }
  }
  //Funcion para hacer corazones de Internet
  function corazon(r, paso,separacion) {
  let puntos = [];
  for (var a = 0; a < 2 * Math.PI; a += paso) {
    let p = {};
    p.x = (circlePosX + separacion) + 16 * r * (Math.sin(a) * Math.sin(a) * Math.sin(a));
    p.y =
      circlePosY -
      13 * r * Math.cos(a) +
      5 * r * Math.cos(2 * a) +
      2 * r * Math.cos(3 * a) +
      1 * r * Math.cos(4 * a);
    puntos.push(p);
  }
  return puntos;
}
//funcion que dibuja corazones junto con la funcion de arriba
function dibujarCorazonEnCanvas(separacion) {

  let puntos = corazon(1, 0.05,separacion);
  ctx.beginPath();
  ctx.moveTo(puntos[0].x, puntos[0].y);
  puntos.forEach(p => {
  ctx.lineTo(p.x, p.y);
  });
  ctx.closePath();
  ctx.fillStyle = "red";
  ctx.fill();
  }

  function contadorPermite(){
    if(permite==false){
      permiteCont--;
      if(permiteCont==0){
        permite = true;
        permiteCont=100;
      }
    }
  }


  function setBackground(){
    ctx.clearRect(0,0,c_width,c_height);
    ctx.fillStyle = "black";
    ctx.strokeRect(0,0,c_width,c_height);
    backGround.y += groundVel;
    if(backGround.y >= c_height){
      backGround.y = 0;
    }

    ctx.drawImage(br,backGround.x,backGround.y,c_width,c_height);
    ctx.drawImage(br,backGround.x,backGround.y - c_height+2 ,c_width,c_height);
    //ctx.moveTo(0,450);
    //ctx.lineTo(800,450);
    ctx.stroke();
    ctx.fillStyle = "gray";
    ctx.fillRect(250,0,300,c_height);
    ctx.fillStyle = "black";
    ctx.strokeRect(250,0,300,c_height);
    separacion = 0;

    for(let i=0; i<vidas; i++){

       dibujarCorazonEnCanvas(separacion);
       separacion+=35;
    }
  }



  function updateGame(){
    setBackground();
    mueveRayas();
    meteRayas();
    pintaRayas();
    checkBidonColision();
    setAnimals();
    setHumos();
    setPajas();
    setBidones();
    coche.newPos();
    coche.drawIt();

    ctx.fillStyle = "yellow";
    ctx.font = '50px Safari-PersonalUse';
    ctx.strokeText("Puntuación: "+score_int, 550, 70);
    ctx.fillText("Puntuación: "+score_int, 550, 70);
    puntFinal.innerHTML = score_int;




    ctx.fillStyle = "yellow";
    ctx.font = '50px Safari-PersonalUse';
    ctx.strokeText("Combustible: "+gasolina, 550, 120);
    ctx.fillText("Combustible: "+gasolina, 550, 120);

    checkGasolineLevel();

    if(checkGasolineLevel()){
      ctx.font = "50px Safari-PersonalUse";
      ctx.fillStyle = "yellow";
      ctx.fillText(
        " Puntuación total :" + (score_int),
        300,
        canvas.height / 2 - 10
      );
      setTimeout(function(){
        elem.style.display = "none";
        model.style.display = "flex";
      },5000)


      return;
    }
    contadorPermite();

    if(checkAnimalColision()){
    if(vidas>0){
      vidas--;
     }
     if(vidas<=0){
       ctx.font = "50px Safari-PersonalUse";
       ctx.fillStyle = "yellow";
       ctx.fillText(
         " Puntuación total :" + (score_int),
         300,
         canvas.height / 2 - 10
       );
       setTimeout(function(){
         elem.style.display = "none";
         model.style.display = "flex";
       },5000)


       return;
     }
    }

    requestAnimationFrame(updateGame);

    fotograma++;


    if(coche.posY >= 500) score += 0.01;
    else{
      score += 0.20;
    }
    score_int = Math.floor(score);
    gasolina-=0.8;
    //console.log(fotograma);
  }
  window.addEventListener('keydown', function (e) {
       tecla = (tecla || []);
       tecla.keys[e.keyCode] = true;
     })
  window.addEventListener('keyup', function (e) {
       tecla.keys[e.keyCode] = false;


     })






     startGame.addEventListener('click', () => {
       resetValues();
       model.style.display = 'none';
       console.log('go');
     });
