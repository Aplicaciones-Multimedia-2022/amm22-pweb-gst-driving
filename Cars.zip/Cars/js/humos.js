let humos = [];

class Humo{
  constructor(){
    this.posX = coche.posX + (coche.width/2);
    //this.posX = coche.posX + Math.random()*coche.width;
    this.posY = coche.posY + coche.height-5;
    this.radio = Math.random() * 8 + 2;
    this.velX = (Math.random() * 1 - 0.5)*6;
    this.velY = groundVel;
    this.color = "white";
  }

  newPos(){
    this.posX +=this.velX;
    this.posY +=this.velY;
  }

  drawIt(){

    if(coche.posX <= 250 || coche.posX >= 550 ){
      ctx.fillStyle = "peru";
    }
    else{
      ctx.fillStyle = this.color;
    }
    ctx.beginPath();
    ctx.arc(this.posX, this.posY, this.radio, 0, Math.PI * 2);
    ctx.fill();
  }
}

function setHumos(){
  humos.unshift(new Humo());
  for (i = 0; i <humos.length; i++) {
    humos[i].newPos();
    humos[i].drawIt();
   }

  if (humos.length > 25) {
    for (let i = 0; i < 20; i++) {
      humos.pop(humos[i]);
  }
 }
}
