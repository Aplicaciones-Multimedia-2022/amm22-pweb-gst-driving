const aceleraAudio = new Audio("./assets/media/aceleracion.mpeg");
const cocheImg = new Image();
cocheImg.src = "./assets/img/coche.png";
class Coche {

  constructor(){
    this.posX = 300;
    //395
    this.posY = 200;
    //300
    this.width = 44;
    this.height = 80;
    this.velY = 0;
    this.velX = 0;
    this.deceleracion = 1;
  }

  newPos(){
    if(coche.posX <= 250 || coche.posX >= 550 ){
      this.deceleracion = 1.15;
    }
    else{
      this.deceleracion = 1;
    }
    this.velY += this.deceleracion;
    this.velY *= 0.9;
    this.posY += this.velY;
    this.velX = 0;
    chechPajaColision();

    if(this.posY >= c_height - this.height){
       this.posY = c_height - this.height;
    }
    if(this.posX<=0){
      this.posX = 0;
    }
    if(this.posX>=c_width- this.width){
      this.posX = c_width- this.width;
    }
    if(tecla && tecla.keys[39]){
      this.velX = 7;
    }
    if(tecla && tecla.keys[37]){
      this.velX = -7;
    }

    this.posX += this.velX;

    if(tecla && tecla.keys[38]){

      aceleraAudio.play();
      this.velY -=1.25;

    }

    else{

      aceleraAudio.pause();
      aceleraAudio.load();
    }
  }

  drawIt(){
    ctx.fillStyle = "yellow";
    ctx.drawImage(cocheImg,coche.posX,coche.posY,coche.width,coche.height);
  }
}
let coche = new Coche();
